/*
Phi_keypads library

Programmed by Dr. John Liu
Revision: 12/18/2011
Free software for educational and personal uses.
No warrantee!
Commercial use without authorization is prohibited.
Find details of the Phi-1 shield, Phi-2 shield or contact Dr. Liu at
http://liudr.wordpress.com/phi-1-shield/
http://liudr.wordpress.com/phi-2-shield/
All rights reserved.
Update:
12/18/2011: Modified to run on both arduino IDE 1.0 and pre-1.0 versions
*/
#ifndef phi_keypads_h
#define phi_keypads_h
#if ARDUINO < 100
#include <WProgram.h>
#else
#include <Arduino.h>
#endif
#include <phi_interfaces.h>

#define Liudr_shift_register_pad 1
#define Single_button_pad 2 //Buttons have to be pulled up, not pulled down. So they connect the pins to GND.
#define Matrix3X4 3
#define Matrix4X4 4
#define Rotary_encoder 5
#define PS2_keyboard 6

#define buttons_up 0 // no-transitional
#define buttons_pressed 1 // transitional
#define buttons_down 2 // no-transitional
#define buttons_held 3
#define buttons_released 4 // transitional
#define buttons_debounce 5 // One needs to wait till debounce is over to become pressed.
#define buttons_hold_time 1000
#define buttons_debounce_time 50
#define NO_KEYs 255 // This is no key in scan code, internal to the library.
#define NO_KEY 0 // This is no key that the library outputs, to be compatible with keypad.h

class phi_rotary_encoders: public multiple_button_input{
  public:
  phi_rotary_encoders(char *na, byte ChnA, byte ChnB, byte det); // Constructor for rotary encoder. Provide the names of up and down actions such as 1, and 2, or 'U' and 'D' and number of detent per rotation. Please define the shaft click as a regular phi_buttons button. 
  byte getKey(); // Returns the key corresponding to dial up or down or NO_KEY.
  byte get_status(); // Always returns buttons_up since the encoder works differently than other keypads that could make use of held or down or released. With the way the encoder is sensed, a dial up/down is alwas a released and can't be held.
  byte get_sensed(); // Always returns NO_KEY since the encoder works differently than other keypads.
  byte get_keypad_type(); // This always returns the type number of rotary encoder.
  byte get_angle(); // Get th angle or orientation of the rotary encoder between 0 and detent-1. This function calls getKey to update the angle. If you call getKey BEFORE get_angle, you get the dial up/down from getKey and the correct angle from get_angle. If you call get_angle BEFORM getKey, the dial up/down is read and lost but you get the correct angle. So make your decision. Do you want just dial up/down actions? Then only call getKey. Do you want just angle? Then only call get_angle. Chances of you need them both is very slim but as mentioned you should call getKey first. 
  
  protected:
  byte EncoderChnA;
  byte EncoderChnB;
  byte detent;
  byte stat_seq_ptr;
  byte counter;
  char * key_names; // Translated names of the keys, such as '0'.
};

class phi_keypads:public multiple_button_input
{
  public:
  unsigned long button_status_t; // This is the time stamp of the sensed button first in the status stored in button_status.
  byte ledStatusBits;  // This variable contains the LED status bits.

  protected:
  byte rows;
  byte columns;
  byte buttonBits; // This is the button bits. Not very useful.
  byte button_sensed; // This indicates which button is sensed or 255 if no button is sensed.
  byte button_status; // This indicates the status of the button if button_sensed is not 255.
  byte * mySensorPins; // Row pins for liudr shift register pad and all pins for matrix keypad, rows first then columns.
  char * key_names; // Translated names of the keys, such as '0'.

  byte getKey(); // Returns the key corresponding to dial up or down or NO_KEY.
  byte scanKeypad(); // Updates scan code of button_sensed and button_status to provide information to getKey
  virtual byte sense_all()=0; // Scan all input pins to privide information to scanKeypad
};

class phi_matrix_keypads: public phi_keypads{
  public:
  phi_matrix_keypads(char *na, byte * sp, byte r, byte c); // Constructor for matrix keypad. Provide the names of the keys such as '1', '2' etc, row and column pins, rows and columns of the keypad. Please define the A, B, C, D, *, and # as 1,2,3,4,5, and 6 in the key names if you intend to use phi_prompt with this keypad. 
  byte get_keypad_type(); // This always returns the type number of matrix keypads 3X4 or 4X4.
  
  protected:
  byte sense_all(); // Senses all input pins for a valid status. The scanKeypad actually interprets the status of the key.
};

class phi_liudr_keypads: public phi_keypads{
  public:
  phi_liudr_keypads(char *na, byte * sp, byte cp, byte dp, byte lp, byte r, byte c); // Constructor for liudr keypad led 
  byte get_keypad_type(); // This always returns the type number of liudr keypad.
  void setLed(byte led, byte on_off);
  void setLedByte(byte led);
  
  protected:
  byte clockPin; // Clock pin for liudr shift register pad or for PS/2 keyboard, or channel A for rotary encoder
  byte dataPin; // Data pin for liudr shift register pad or for PS/2 keyboard, or channel B for rotary encoder
  byte latchPin; // Latch or storage pin for liudr shift register pad.
  byte ledStatusBits;  // This variable contains the LED status bits.

  byte sense_all(); // Senses all input pins for a valid status. The scanKeypad actually interprets the status of the key.
  void updateShiftRegister(byte first8, byte next8);
};

#endif

