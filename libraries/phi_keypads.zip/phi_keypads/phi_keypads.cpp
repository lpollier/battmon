/*
Phi_keypads library

Programmed by Dr. John Liu
Revision: 12/18/2011
Free software for educational and personal uses.
No warrantee!
Commercial use without authorization is prohibited.
Find details of the Phi-1 shield, Phi-2 shield or contact Dr. Liu at
http://liudr.wordpress.com/phi-1-shield/
http://liudr.wordpress.com/phi-2-shield/
All rights reserved.
Update:
12/18/2011: Modified to run on both arduino IDE 1.0 and pre-1.0 versions
12/28/2011: Added phi_interfaces support and constructor definitions for analog keypad and rotary encoder
*/
#if ARDUINO < 100
#include <WProgram.h>
#else
#include <Arduino.h>
#endif
#include <phi_interfaces.h>
#include "phi_keypads.h"

phi_keypads::phi_keypads() // Used by decendent classes
{
}

byte phi_keypads::get_sensed() // Outputs the sensed key or NO_KEY even if the sensed key state is not pressed. You can use this in conjunction with get_status to sense if a key is held and repeat the held key if you want.
{
  if (button_sensed==NO_KEYs) return NO_KEY;
  else return key_names[button_sensed];
}

byte phi_keypads::get_status() // Return status of the sensed key. If there is no sensed key, this return should not be used.
{
  return button_status;
}

byte phi_keypads::get_keypad_type() // Returns the keypad_type such as Liudr pad, matrix keypad, rotary encoder etc.
{
  return keypad_type;
}

byte phi_keypads::getKey() // This is the public method to get a key press from the keypad. The key press is translated into key_names or NO_KEY.
{
  byte key=scanKeypad();
  if (key==NO_KEYs) key=NO_KEY;
  else key=key_names[key];
  return key;
}

byte phi_keypads::scanKeypad() //This routine uses senseAll to scan the keypad, use debouncing to update button_sensed and button_status. The getKey translates keypress from scan code (0-15) into meaningful characters.
{
  byte button_pressed=sense_all();
  
  switch (button_status)
  {
    case buttons_up:
    if (button_pressed!=NO_KEYs)
    {
      button_sensed==button_pressed;
      button_status_t=millis();
      button_status=buttons_debounce;
    }
    else button_sensed=NO_KEYs;
    break;
    
    case buttons_debounce:
    if (button_pressed!=NO_KEYs)
    {
      if (button_sensed==button_pressed)
      {
        if (millis()-button_status_t>buttons_debounce_time)
        {
          button_status=buttons_pressed;
          button_status_t=millis();
          return button_sensed;
        }
      }
      else
      {
        button_status_t=millis();
        button_sensed=button_pressed;
      }
    }
    else
    {
      button_status=buttons_up;
      button_sensed=NO_KEYs;
    }
    break;
    
    case buttons_pressed:
    if (button_pressed!=NO_KEYs)
    {
      if (button_sensed==button_pressed) button_status=buttons_down;
      else button_status=buttons_debounce;
      button_status=buttons_down;
    }
    else button_status=buttons_released;
    button_status_t=millis();
    break;
    
    case buttons_down:
    if (button_sensed==button_pressed)
    {
      if (millis()-button_status_t>buttons_hold_time)
      {
        button_status=buttons_held;
        button_status_t=millis();
      }
    }
    else
    {
      button_status=buttons_released;
      button_status_t=millis();
    }
    break;
    
    case buttons_released:
    if (button_pressed==NO_KEYs) button_status=buttons_up;
    else
    {
      button_status=buttons_debounce;
      button_sensed=button_pressed;
      button_status_t=millis();
    }
    break;
    
    case buttons_held:
    if (button_sensed!=button_pressed)
    {
      button_status=buttons_released;
      button_status_t=millis();
    }
    break;
  }
  return NO_KEYs;
}

//Rotary encoder class member functions:
phi_rotary_encoders::phi_rotary_encoders(char *na, byte ChnA, byte ChnB, byte det) // Rotary encoder constructor
{
//  phi_keypads();
  key_names=na; // Translated names of the keys, such as '0'.
  EncoderChnA=ChnA;
  EncoderChnB=ChnB;
  
  pinMode(EncoderChnA, INPUT);
  digitalWrite(EncoderChnA, HIGH);
  pinMode(EncoderChnB, INPUT);
  digitalWrite(EncoderChnB, HIGH);

  detent=det;
  stat_seq_ptr=4; // Center the status of the encoder
  counter=0;
}

byte phi_rotary_encoders::getKey() // This actually performs the encoder read and returns up or down dials with the translation done by key_names
{
  static const byte stat_seq[]={3,2,0,1,3,2,0,1,3}; // For always on switches use {0,1,3,2,0,1,3,2,0}; For the sake of simple coding, please don't mix always-on encoders with always-off encoders.
  byte stat_int=(digitalRead(EncoderChnB)<<1) | digitalRead(EncoderChnA);
  if (stat_int==stat_seq[stat_seq_ptr+1])
  {
    stat_seq_ptr++;
    if (stat_seq_ptr==8)
    {
      stat_seq_ptr=4;
      counter++;
      return key_names[0];
    }
  }
  else if (stat_int==stat_seq[stat_seq_ptr-1])
  {
    stat_seq_ptr--;
    if (stat_seq_ptr==0)
    {
      stat_seq_ptr=4;
      counter--;
      return key_names[1];
    }
  }
  else return NO_KEY;
}

byte phi_rotary_encoders::get_status()
{
  return buttons_up;
}

byte phi_rotary_encoders::get_sensed()
{
  return NO_KEY;
}

byte phi_rotary_encoders::get_angle()
{
  getKey();
  return (((int)counter)%detent+detent)%detent;
}

byte phi_rotary_encoders::get_keypad_type()
{
  return Rotary_encoder;
}

//Analog keys class member functions

//Matrix keypads class member functions
phi_matrix_keypads::phi_matrix_keypads(char *na, byte * sp, byte r, byte c) // Matrix keypads constructor
{
  if ((r==4)&&(c==3))keypad_type=Matrix3X4;
  if ((r==4)&&(c==4))keypad_type=Matrix4X4;

  key_names=na; // Translated names of the keys, such as '0'.
  mySensorPins=sp; // Row pins
  rows=r;
  columns=c;
  button_sensed=NO_KEYs; // This indicates which button is sensed or 255 if no button is sensed.
  button_status=buttons_up; // This indicates the status of the button if button_sensed is not 255.
  button_status_t=millis();; // This is the time stamp of the sensed button first in the status stored in button_status.
  
  for (int j=0;j<rows;j++) // Setting sensing rows to input and enabling internal pull-up resistors.
  {
    pinMode(mySensorPins[j],INPUT);
    digitalWrite(mySensorPins[j],HIGH);
  }

  for (int j=rows;j<columns+rows;j++) // Setting columns to HIGH.
  {
    pinMode(mySensorPins[j],OUTPUT);
    digitalWrite(mySensorPins[j],HIGH);
  }
}

byte phi_matrix_keypads::sense_all()
// Returns the button that is pressed down or NO_KEYs if no button is pressed down. The return is 0-based so the value is 0-15 for 16 key pads.
{

  for (byte j=0;j<rows;j++)
  {
    for (byte i=0;i<columns;i++)
    {
      digitalWrite(mySensorPins[rows+i],LOW);
      buttonBits=digitalRead(mySensorPins[j]); // Sensing button, using buttonBits as a temp variable.
      digitalWrite(mySensorPins[rows+i],HIGH); 
      if (buttonBits==LOW)
      {
        return (i+j*columns); // returns the button pressed
      }
    }
  }
  return NO_KEYs; // no buttons pressed
}

byte phi_matrix_keypads::get_keypad_type()
{
  if (columns==3) return Matrix3X4;
  else if (columns==4) return Matrix4X4;
}

//Liudr shift register keypads class member functions
phi_liudr_keypads::phi_liudr_keypads(char *na, byte * sp, byte cp, byte dp, byte lp, byte r, byte c) // Liudr shift register pad
{
  ledStatusBits=0;
  buttonBits=255;
  key_names=na; // Translated names of the keys, such as '0'.
  mySensorPins=sp; // Row pins
  clockPin=cp;
  dataPin=dp;
  latchPin=lp;
  rows=r;
  columns=c;
  button_sensed=NO_KEYs; // This indicates which button is sensed or 255 if no button is sensed.
  button_status=buttons_up; // This indicates the status of the button if button_sensed is not 255.
  button_status_t=millis();; // This is the time stamp of the sensed button first in the status stored in button_status.
  
  for (int j=0;j<rows;j++) // Setting sensing rows to input and enabling internal pull-up resistors.
  {
    pinMode(mySensorPins[j],INPUT);
    digitalWrite(mySensorPins[j],HIGH);
  }

  pinMode(dataPin,OUTPUT);
  pinMode(clockPin,OUTPUT);
  pinMode(latchPin,OUTPUT);

  updateShiftRegister(ledStatusBits,buttonBits);
}

byte phi_liudr_keypads::get_keypad_type()
{
  return Liudr_shift_register_pad;
}

void phi_liudr_keypads::updateShiftRegister(byte first8, byte next8)  // Updates LED status using shift registers. Two bytes are shifted out.
{
  digitalWrite(latchPin, LOW);  // Disable update to the output buffers.
  shiftOut(dataPin, clockPin, MSBFIRST, first8);//MSBFIRST when flat LSBFIRST when standing.
  shiftOut(dataPin, clockPin, LSBFIRST, next8);//MSBFIRST when flat LSBFIRST when standing.
  digitalWrite(latchPin, HIGH);  // Enable update to the output buffers.
}

void phi_liudr_keypads::setLed(byte led, byte on_off)
{
  bitWrite(ledStatusBits,led,on_off);
  updateShiftRegister(ledStatusBits,buttonBits);
}


void phi_liudr_keypads::setLedByte(byte led)
{
  ledStatusBits=led;
  updateShiftRegister(ledStatusBits,buttonBits);
}

byte phi_liudr_keypads::sense_all()
// Returns the button that is pressed down or NO_KEYs if no button is pressed down. The return is 0-based so the value is 0-15 for 16 key pads.
{

  for (byte j=0;j<rows;j++)
  {
    for (byte i=0;i<columns;i++)
    {
        buttonBits=255;
        bitClear(buttonBits,i);
        updateShiftRegister(ledStatusBits,buttonBits);

      buttonBits=digitalRead(mySensorPins[j]); // Sensing button, using buttonBits as a temp variable.

      if (buttonBits==LOW)
      {
        return (i+j*columns); // returns the button pressed
      }
    }
  }
  return NO_KEYs; // no buttons pressed
}

/* old code
phi_keypads::phi_keypads(char *na, byte * sp, byte cp, byte dp, byte lp, byte r, byte c) // Liudr shift register pad
{
  keypad_type=Liudr_shift_register_pad; // 
  ledStatusBits=0;
  buttonBits=255;
  key_names=na; // Translated names of the keys, such as '0'.
  mySensorPins=sp; // Row pins
  clockPin=cp;
  dataPin=dp;
  latchPin=lp;
  rows=r;
  columns=c;
  button_sensed=NO_KEYs; // This indicates which button is sensed or 255 if no button is sensed.
  button_status=buttons_up; // This indicates the status of the button if button_sensed is not 255.
  button_status_t=millis();; // This is the time stamp of the sensed button first in the status stored in button_status.
  
  for (int j=0;j<rows;j++) // Setting sensing rows to input and enabling internal pull-up resistors.
  {
    pinMode(mySensorPins[j],INPUT);
    digitalWrite(mySensorPins[j],HIGH);
  }

  pinMode(dataPin,OUTPUT);
  pinMode(clockPin,OUTPUT);
  pinMode(latchPin,OUTPUT);

  updateShiftRegister(ledStatusBits,buttonBits);
}

phi_keypads::phi_keypads(char *na, byte * sp, byte r, byte c) // Matrix keypads
{
  if ((r==4)&&(c==3))keypad_type=Matrix3X4;
  if ((r==4)&&(c==4))keypad_type=Matrix4X4;

  key_names=na; // Translated names of the keys, such as '0'.
  mySensorPins=sp; // Row pins
  rows=r;
  columns=c;
  button_sensed=NO_KEYs; // This indicates which button is sensed or 255 if no button is sensed.
  button_status=buttons_up; // This indicates the status of the button if button_sensed is not 255.
  button_status_t=millis();; // This is the time stamp of the sensed button first in the status stored in button_status.
  
  for (int j=0;j<rows;j++) // Setting sensing rows to input and enabling internal pull-up resistors.
  {
    pinMode(mySensorPins[j],INPUT);
    digitalWrite(mySensorPins[j],HIGH);
  }

  for (int j=rows;j<columns+rows;j++) // Setting columns to HIGH.
  {
    pinMode(mySensorPins[j],OUTPUT);
    digitalWrite(mySensorPins[j],HIGH);
  }
}

void phi_keypads::updateShiftRegister(byte first8, byte next8)  // Updates LED status using shift registers. Two bytes are shifted out.
{
  digitalWrite(latchPin, LOW);  // Disable update to the output buffers.
  shiftOut(dataPin, clockPin, MSBFIRST, first8);//MSBFIRST when flat LSBFIRST when standing.
  shiftOut(dataPin, clockPin, LSBFIRST, next8);//MSBFIRST when flat LSBFIRST when standing.
  digitalWrite(latchPin, HIGH);  // Enable update to the output buffers.
}

void phi_keypads::setLed(byte led, byte on_off)
{
  bitWrite(ledStatusBits,led,on_off);
  updateShiftRegister(ledStatusBits,buttonBits);
}


void phi_keypads::setLedByte(byte led)
{
  ledStatusBits=led;
  updateShiftRegister(ledStatusBits,buttonBits);
}

byte phi_keypads::sense_all()
// Returns the button that is pressed down or 255 if no button is pressed down. The return is 0-based so the value is 0-15 for 16 key pads.
{

  for (byte j=0;j<rows;j++)
  {
    for (byte i=0;i<columns;i++)
    {
      switch (keypad_type) // Pre-sensing setup
      {
        case Liudr_shift_register_pad:
        buttonBits=255;
        bitClear(buttonBits,i);
        updateShiftRegister(ledStatusBits,buttonBits);
        break;

        case Matrix3X4:
        case Matrix4X4:
        digitalWrite(mySensorPins[rows+i],LOW);
        break;
        case Single_button_pad:
        break;
      }

      buttonBits=digitalRead(mySensorPins[j]); // Sensing button, using buttonBits as a temp variable.

      switch (keypad_type) // Post sensing treatment
      {
        case Liudr_shift_register_pad:
        case Single_button_pad:
        break;

        case Matrix3X4:
        case Matrix4X4:
        digitalWrite(mySensorPins[rows+i],HIGH);
        break;
      }
      if (buttonBits==LOW)
      {
        return (i+j*columns); // returns the button pressed
      }
    }
  }
  return NO_KEYs; // no buttons pressed
}

*/
